module.exports = {
	plugins: {
		autoprefixer: {},
	},
};
