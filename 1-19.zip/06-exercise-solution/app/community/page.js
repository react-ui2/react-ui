export default function CommunityPage() {
  return <h1>Community</h1>;
}
