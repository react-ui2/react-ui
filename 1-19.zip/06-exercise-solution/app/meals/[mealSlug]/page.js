export default function MealDetailsPage() {
  return <h1>Meal Details</h1>;
}
