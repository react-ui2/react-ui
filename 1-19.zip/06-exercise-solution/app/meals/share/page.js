export default function ShareMealPage() {
  return <h1>Share Meal</h1>;
}
