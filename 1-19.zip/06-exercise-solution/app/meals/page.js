export default function MealsPage() {
  return <h1>Meals Page</h1>;
}
