export default {
  plugins: {
    "tailwindcss/nesting": {},
    tailwindcss: {},
    autoprefixer: {},
    cssnano: { preset: "default" },
    "postcss-import": {},
  },
};
