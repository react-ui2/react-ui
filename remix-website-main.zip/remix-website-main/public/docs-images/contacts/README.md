These images are used by remix/docs/tutorial.md

The `convert.sh` script will convert them all to webp.
