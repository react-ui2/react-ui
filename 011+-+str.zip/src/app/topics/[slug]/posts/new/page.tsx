export default function PostCreatePost() {
  return <div>Post Create Pag</div>;
}
