export default {
  presets: [require.resolve('@docusaurus/core/lib/babel/preset')],
};
