export { docsearch as default } from './docsearch';
