export { DocSearchModal } from './dist/esm';
