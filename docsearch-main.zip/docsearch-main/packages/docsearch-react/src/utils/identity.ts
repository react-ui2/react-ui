export function identity<TParam>(x: TParam): TParam {
  return x;
}
