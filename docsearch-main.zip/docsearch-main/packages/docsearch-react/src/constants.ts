export const MAX_QUERY_SIZE = 64;
