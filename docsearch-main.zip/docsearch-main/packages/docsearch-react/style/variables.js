export * from '@docsearch/css/dist/_variables.css';
