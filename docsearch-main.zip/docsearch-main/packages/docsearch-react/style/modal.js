export * from '@docsearch/css/dist/modal.css';
