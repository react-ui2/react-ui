export { DocSearchButton } from './dist/esm';
