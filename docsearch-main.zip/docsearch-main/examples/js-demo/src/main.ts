import docsearch from '@docsearch/js';

import './app.css';
import '@docsearch/css/dist/style.css';

docsearch({
  container: '#docsearch',
  indexName: 'docsearch',
  appId: 'R2IYF7ETH7',
  apiKey: '599cec31baffa4868cae4e79f180729b',
});
