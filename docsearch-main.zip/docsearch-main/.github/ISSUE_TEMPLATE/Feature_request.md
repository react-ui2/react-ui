---
name: Feature request
about: Suggest an idea for DocSearch.
---

## Describe the problem

<!-- Explain why a new feature is required. -->

## Describe the solution

<!-- Explain what your solution would look like. -->

## Alternatives you've considered

<!-- Is the proposed solution not the only one you've thought about? Please tell us more! -->
