---
id: statusbarios
title: '🚧 StatusBarIOS'
---

> **Deleted.** Use [`StatusBar`](statusbar.md) for mutating the status bar.

---
