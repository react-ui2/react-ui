> If you previously installed a global `react-native-cli` package, please remove it as it may cause unexpected issues:
>
> ```shell
> npm uninstall -g react-native-cli @react-native-community/cli
> ```
