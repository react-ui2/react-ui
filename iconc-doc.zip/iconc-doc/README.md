# Ionic Docs

The official [Ionic](https://ionicframework.com) documentation, built with [Docusaurus](https://docusaurus.io/).

[![Crowdin](https://badges.crowdin.net/ionic-docs/localized.svg)](https://crowdin.com/project/ionic-docs)

---

- [Contributing Guide](./CONTRIBUTING.md) :flashlight:
<!-- - [Project Board](https://github.com/ionic-team/ionic-docs/projects/3) :pushpin: -->
