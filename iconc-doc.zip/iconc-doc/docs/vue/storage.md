---
title: Data Storage
sidebar_label: Storage
---

<head>
  <title>Vue App Data Storage for iOS and Android - Ionic Documentation</title>
  <meta
    name="description"
    content="There's a variety of options available for storing data within an Ionic app. Read our Vue data storage documentation for options on iOS, Android, and web apps."
  />
</head>

There are variety of options available for storing data within an Ionic app.

Here are two official Ionic options:

## Ionic Secure Storage

For teams building mission-critical apps or requiring encryption support, [Ionic Secure Storage](https://ionic.io/docs/secure-storage) is an official premium solution from the Ionic team that provides a cross-platform data storage system that works on iOS and Android.

It makes it easy to build high performance, offline-ready Ionic apps across iOS, Android, and the web.

[Learn more](https://ionic.io/products/secure-storage)

## @ionic/storage

For developers not requiring encryption nor relational data support, [@ionic/storage](https://github.com/ionic-team/ionic-storage) is an open source key/value API for building apps that work across storage engines on multiple platforms.

Additionally, Ionic Secure Storage has a driver that works with the key/value API in `@ionic/storage` while providing encryption and SQLite support.

Learn more about [@ionic/storage](https://github.com/ionic-team/ionic-storage)
