---
title: "ion-fab-list"
---
import Props from '@ionic-internal/component-api/v8/fab-list/props.md';
import Events from '@ionic-internal/component-api/v8/fab-list/events.md';
import Methods from '@ionic-internal/component-api/v8/fab-list/methods.md';
import Parts from '@ionic-internal/component-api/v8/fab-list/parts.md';
import CustomProps from '@ionic-internal/component-api/v8/fab-list/custom-props.mdx';
import Slots from '@ionic-internal/component-api/v8/fab-list/slots.md';

import EncapsulationPill from '@components/page/api/EncapsulationPill';

<EncapsulationPill type="shadow" />

The fab list component is a container for multiple [fab buttons](./fab-button). It contains actions related to the main fab button and is flung out on click. To specify what side the buttons should appear on, set the `side` property to `"start"`, `"end"`, `"top"`, or `"bottom"`.

For usage examples, see the [fab documentation](./fab).

## Properties
<Props />

## Events
<Events />

## Methods
<Methods />

## CSS Shadow Parts
<Parts />

## CSS Custom Properties
<CustomProps />

## Slots
<Slots />