---
title: "ion-item-group"
---
import Props from '@ionic-internal/component-api/v8/item-group/props.md';
import Events from '@ionic-internal/component-api/v8/item-group/events.md';
import Methods from '@ionic-internal/component-api/v8/item-group/methods.md';
import Parts from '@ionic-internal/component-api/v8/item-group/parts.md';
import CustomProps from '@ionic-internal/component-api/v8/item-group/custom-props.mdx';
import Slots from '@ionic-internal/component-api/v8/item-group/slots.md';

<head>
  <title>ion-item-group: Group Items to Divide into Multiple Sections</title>
  <meta name="description" content="Item groups are containers that organize similar items together. ion-item-groups can contain item dividers to divide the items into multiple sections. " />
</head>

import EncapsulationPill from '@components/page/api/EncapsulationPill';


Item groups are containers that organize similar [items](./item) together. They can contain [item dividers](./item-divider) to divide the items into multiple sections. They can also be used to group [sliding items](./item-sliding).

## Basic Usage

import Basic from '@site/static/usage/v8/item-group/basic/index.md';

<Basic />

## Sliding Items

import SlidingItems from '@site/static/usage/v8/item-group/sliding-items/index.md';

<SlidingItems />


## Properties
<Props />

## Events
<Events />

## Methods
<Methods />

## CSS Shadow Parts
<Parts />

## CSS Custom Properties
<CustomProps />

## Slots
<Slots />
