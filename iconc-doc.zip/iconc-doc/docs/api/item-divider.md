---
title: "ion-item-divider"
---
import Props from '@ionic-internal/component-api/v8/item-divider/props.md';
import Events from '@ionic-internal/component-api/v8/item-divider/events.md';
import Methods from '@ionic-internal/component-api/v8/item-divider/methods.md';
import Parts from '@ionic-internal/component-api/v8/item-divider/parts.md';
import CustomProps from '@ionic-internal/component-api/v8/item-divider/custom-props.mdx';
import Slots from '@ionic-internal/component-api/v8/item-divider/slots.md';

<head>
  <title>ion-item-divider: Item Divider Block Element for Ionic Apps</title>
  <meta name="description" content="Item Dividers are block elements that can be used to separate items in a list. They are similar to list headers, but instead, go in between groups of items." />
</head>

import EncapsulationPill from '@components/page/api/EncapsulationPill';

<EncapsulationPill type="shadow" />


Item dividers are block elements that can be used to separate [items](./item) in a list. They are similar to list headers, but instead of only being placed at the top of a list, they should go in between groups of items.


## Basic Usage

import Basic from '@site/static/usage/v8/item-divider/basic/index.md';

<Basic />


## Theming

### Colors

import Colors from '@site/static/usage/v8/item-divider/theming/colors/index.md';

<Colors />


### CSS Custom Properties

import CSSProps from '@site/static/usage/v8/item-divider/theming/css-properties/index.md';

<CSSProps />


## Properties
<Props />

## Events
<Events />

## Methods
<Methods />

## CSS Shadow Parts
<Parts />

## CSS Custom Properties
<CustomProps />

## Slots
<Slots />
