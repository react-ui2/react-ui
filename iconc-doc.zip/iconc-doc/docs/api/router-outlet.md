---
title: "ion-router-outlet"
---

import Props from '@ionic-internal/component-api/v8/router-outlet/props.md';
import Events from '@ionic-internal/component-api/v8/router-outlet/events.md';
import Methods from '@ionic-internal/component-api/v8/router-outlet/methods.md';
import Parts from '@ionic-internal/component-api/v8/router-outlet/parts.md';
import CustomProps from '@ionic-internal/component-api/v8/router-outlet/custom-props.mdx';
import Slots from '@ionic-internal/component-api/v8/router-outlet/slots.md';



import EncapsulationPill from '@components/page/api/EncapsulationPill';

<EncapsulationPill type="shadow" />


The router outlet behaves in a similar way to Angular's built-in router outlet component and Vue's router view component, but contains the logic for providing a stacked navigation, and animating views in and out.

Although router outlet has methods for navigating around, it's recommended to use the navigation methods in your framework's router.

## Life Cycle Hooks

Routes rendered in a Router Outlet have access to specific Ionic events that are wired up to animations


| Event Name         | Trigger                                                            |
|--------------------|--------------------------------------------------------------------|
| `ionViewWillEnter` | Fired when the component routing to is about to animate into view. |
| `ionViewDidEnter`  | Fired when the component routing to has finished animating.        |
| `ionViewWillLeave` | Fired when the component routing from is about to animate.         |
| `ionViewDidLeave`  | Fired when the component routing to has finished animating.        |


These event tie into Ionic's animation system and can be used to coordinate parts of your app when a Components is done with its animation. These events are not a replacement for your framework's own event system, but an addition.

For handling Router Guards, the older `ionViewCanEnter` and `ionViewCanLeave` have been replaced with their framework specific equivalent. For Angular, there are [Router Guards](https://angular.io/guide/router#milestone-5-route-guards).




## Properties
<Props />

## Events
<Events />

## Methods
<Methods />

## CSS Shadow Parts
<Parts />

## CSS Custom Properties
<CustomProps />

## Slots
<Slots />