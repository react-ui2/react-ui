# Videos

### [Ionic 2 Crash Course](https://www.youtube.com/watch?v=O2WiI9QrS5s&feature=youtu.be)

A quick introduction to Ionic 2 and how to build your first app.

### [Ionic &amp; Async](https://blog.ionicframework.com/screencast-ionic-async/)

Learn how to coordinate multiple events in a timely manner.

### [Building a TODO app in Ionic 2](http://www.joshmorony.com/build-a-todo-app-from-scratch-with-ionic-2-video-tutorial/)

Learn how to build out an entire Ionic 2 app.

### [Angular Connect: Ionic 2](https://www.youtube.com/watch?v=bAlydPwFONY)

Dive into some of the ideas and goals behind Ionic 2.

### [Ionic &amp; Typings](https://blog.ionicframework.com/ionic-and-typings/)

Learn how to add typings for libraries you are using in your Ionic 2 app.
