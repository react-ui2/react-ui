# Tools

### [Angular CLI](https://github.com/angular/angular-cli)

Learn more about the power of the Angular CLI

### [StackBlitz](https://stackblitz.com/)

Quickly get started with a new Ionic app entirely in the browser!

### [TypeScript](https://www.typescriptlang.org/)

Check out the features that make working with TypeScript amazing.

### [Glossary](../reference/glossary.md)

A list of common terms you'll see while developing in Ionic.

### [Starter Apps](https://ionicthemes.com)

Ionic Starter Apps to speed up and improve your app development.
