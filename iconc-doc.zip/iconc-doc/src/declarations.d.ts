declare namespace JSX {
  interface IntrinsicElements {
    'device-preview': any;
  }
}
