export default async function RootPage() {
  return <></>;
}
