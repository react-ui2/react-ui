import React from 'react';

export default function NotFound() {
  return <div className="bg-black p-4 text-center text-white">Invalid tab</div>;
}
